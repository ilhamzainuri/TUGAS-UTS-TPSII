<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "db_laundry");
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id_customer'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $JK = $_POST['JK'];
    $phone = $_POST['phone'];

    $query = "UPDATE customer SET nama='$nama', alamat='$alamat', JK='$JK', phone='$phone' WHERE id_customer='$id'";
    if ($koneksi->query($query) === TRUE) {
        $_SESSION['success'] = "Data berhasil diupdate!";
        header("Location: ../admin.php");
        exit;
    } else {
        $_SESSION['error'] = "Gagal mengupdate data: " . $koneksi->error;
        header("Location: editcust.php?id=$id");
        exit;
    }
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM customer WHERE id_customer='$id'";
    $result = $koneksi->query($query);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
    } else {
        echo "Data tidak ditemukan!";
        exit;
    }
} else {
    echo "ID tidak ditemukan!";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Customer</title>
    <link rel="stylesheet" type="text/css" href="sidebar.css">
    <style>
    .button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }</style>
</head>
<body>

<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="../admin.php">Registrasi Pelanggan</a>
        <a href="../outlet/outlet.php">Outlet</a>
        <a href="../services/services.php">Services</a>
        <a href="../user/user.php">User</a>
        <a href="../transaksi/transaksi.php">Transaksi</a>
        <a href="../laporan">Laporan</a>
    </div>
    <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>

<div class="content">
    <h2>Edit Data Customer</h2>
    <form action="" method="post">
        <input type="hidden" name="id_customer" value="<?= $data['id_customer']; ?>">

        <label>Nama:</label><br>
        <input type="text" name="nama" value="<?= $data['nama']; ?>" required><br><br>

        <label>Alamat:</label><br>
        <textarea name="alamat" required><?= $data['alamat']; ?></textarea><br><br>

        <label>Jenis Kelamin:</label><br>
        <select name="JK" required>
            <option value="L" <?= $data['JK'] == 'L' ? 'selected' : ''; ?>>Laki-laki</option>
            <option value="P" <?= $data['JK'] == 'P' ? 'selected' : ''; ?>>Perempuan</option>
        </select><br><br>

        <label>No. Telepon:</label><br>
        <input type="text" name="phone" value="<?= $data['phone']; ?>" required><br><br>

        <button class="btn" type="submit">Update</button>
        <button class="btn" type="button" onclick="window.location.href='../admin.php'">Kembali</button>

    </form>
</div>

</body>
</html>
