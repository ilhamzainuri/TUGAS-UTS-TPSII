<?php
session_start(); 

$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "db_laundry"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = ''; 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM tb_user WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();


        if ($password == $user['password']) {
            $_SESSION['username'] = $user['username'];  
            $_SESSION['role'] = $user['role'];

            if ($user['role'] == 'admin') {
                header("Location: ../admin.php");
            } elseif ($user['role'] == 'kasir') {
                header("Location: ../kasir.php");
            } elseif ($user['role'] == 'owner') {
                header("Location: ../owner.php");
            } else {
                $error = "Role tidak dikenali!";
            }
            exit();
        } else {
            $error = "Invalid password."; 
        }
    } else {
        $error = "Invalid username.";  
    }

    $stmt->close(); 
}

$conn->close(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="stylelogin&signup.css">
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="login.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>

            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>

            <button type="submit">Login</button>
        </form>

        <?php
        if (!empty($error)) {
            echo "<p class='message error'>$error</p>";
        }
        ?>

        <a href="home.php" class="back-button">Back to Home</a>
    </div>
</body>
</html>
