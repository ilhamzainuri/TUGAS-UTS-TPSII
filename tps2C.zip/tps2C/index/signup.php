<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_laundry"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql_outlet = "SELECT * FROM outlet";
$result_outlet = $conn->query($sql_outlet);

$sql_enum = "SHOW COLUMNS FROM tb_user LIKE 'role'";
$result_enum = $conn->query($sql_enum);
$row_enum = $result_enum->fetch_assoc();

preg_match("/^enum\((.*)\)$/", $row_enum['Type'], $matches);
$enum_values = str_getcsv($matches[1], ",", "'");


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $id_outlet = $_POST['outlet'];
    $role = $_POST['role'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($username) || empty($password) || empty($confirm_password) || empty($email) || empty($id_outlet) || empty($role)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $sql = "SELECT * FROM tb_user WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username already taken. Choose a different one.";
        } else {
            $sql = "INSERT INTO tb_user (email, username, password, id_outlet, role) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssis", $email, $username, $password, $id_outlet, $role);


            if ($stmt->execute()) {
                $success = "Signup successful! You can now log in.";
            } else {
                $error = "Error: Could not execute the query.";
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="stylelogin&signup.css">
</head>
<body>
    <div class="signup-container">
        <h2>Create Account</h2>
        <form action="signup.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>

            <label for="email">Email:</label>
            <input type="text" name="email" id="email" required>

            <label>Nama Outlet:</label>
            <select name="outlet" id="outlet" required>
            <option value="">Pilih Outlet</option>
                <?php while ($row = $result_outlet->fetch_assoc()): ?>
                    <option value="<?php echo $row['id_outlet']; ?>">
                        <?php echo $row['nama']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label>Role:</label>
            <select name="role" id="role" required>
            <option value="">Pilih Role</option>
    <?php foreach ($enum_values as $role): ?>
        <option value="<?php echo $role; ?>"><?php echo ucfirst($role); ?></option>
    <?php endforeach; ?>
            </select>

                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" required>

                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" name="confirm_password" id="confirm_password" required>

                    <button type="submit">Sign Up</button>
            </form>

        <?php
        if (!empty($error)) {
            echo "<p class='message error'>$error</p>";
        }
        if (!empty($success)) {
            echo "<p class='message success'>$success</p>";
        }
        ?>

        <p class="login-link">Already have an account? <a href="login.php">Log in here</a>.</p>

        
        <a href="home.php" class="back-button">Back to Home</a>
    </div>
</body>
</html>
