<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Awee Laundry</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <br><br>
    <h1>Selamat Datang di Awee Laundry</h1>
    <p>Kami siap memberikan pelayanan untuk semua jenis pakaian anda</p>
    <a href="login.php" class="login-button">Login</a>
</header>
<nav>
    <a href="home.php">Home</a>
    <a href="#serv">Our Services</a>
    <a href="#outlet">Outlet</a>
    <a href="https://api.whatsapp.com/send?phone=6285820664592&text=Nama%20%3A%0AAlamat%20%3A%0ALayanan%20%3A%0AQTY%20%3A%0AOutlet%20%3A%0ATambahan%20%3A%0APembayaran%20%3A%20qris%2C%20on%20site%0Atgl%20selesai%20%3A%20(minimal%202%20hari%20setelah%20pengantaran%2C%20jika%20pengen%20cepat%20akan%20dikenai%20biaya%20tambahan)%0A" target="_blank">Order Now</a>
</nav>

<div id="services" class="content">
    <h1 class="desc">Tampil bersih <br> dan Percaya diri</h1>
    <img src="icon.png" alt="">
</div>

<section id="serv" class="babycare-section">
        <div class="text-content">
            <h1>Kami siap memberikan solusi terbaik untuk semua kebutuhan pencucian Anda.</h1>
            <p>
            Kami adalah solusi terbaik untuk semua kebutuhan laundry Anda. Mengapa menyita waktu berharga Anda dengan mencuci dan menyetrika sendiri? Percayakan pada layanan laundry profesional kami dan nikmati kenyamanan serta waktu luang yang lebih berarti.
 <br>Di Awee Laundry, kami menawarkan layanan laundry dengan pengantaran langsung ke rumah Anda, tanpa perlu meninggalkan rumah. Nikmati kenyamanan mencuci pakaian dengan layanan antar jemput kami.
            </p>
        </div>
        <div class="image-content">
            <img src="icon2.png" alt="">
        </div>
    </section>

    <section id="service" class="homecare-section">
        <h1>Layanan Awee Laundry</h1>
        <div class="cards">
            <div class="card" onclick="showDescription('desc1')">
                <img src="delivery.png" alt="">
                <p>Layanan Antar Jemput</p>
            </div>
            <div class="card" onclick="showDescription('desc2')">
                <img src="extra.png" alt="">
                <p>Layanan Extra Anti Noda</p>
            </div>
            <div class="card" onclick="showDescription('desc3')">
                <img src="kilat.png" alt="">
                <p>Layanan Laundry Kilat</p>
            </div>
            <div class="card" onclick="showDescription('desc4')">
                <img src="tanparibet.png" alt="">
                <p>Pesan Tanpa Ribet</p>
            </div>
        </div>
    </section>

    <section id="outlet" class="outlet-section">
        <div class="text-content">
            <h1>Daftar Outlet Kami</h1>
            <div class="outlet1">
                <h2>Awee Laundry Bahagia Dinoyo</h2>
            </div>
            <div class="outlet2">
                <h2>Awee Laundry Sahabat Merjosari</h2>
            </div>
            <div class="outlet3">
                <h2>Awee Laundry Queen Araya</h2>
            </div>
        </div>

    </section>

<footer class="footer">
        <div class="footer-content">
            <p>&copy; 2025 Ilham Zainuri 23510010. All rights reserved.</p>
        </div>
</footer>

</body>
</html>
