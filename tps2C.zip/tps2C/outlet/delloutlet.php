<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "db_laundry");

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

if (isset($_GET['dell'])) {
    $id = $koneksi->real_escape_string($_GET['dell']);

    $query = "DELETE FROM outlet WHERE id_outlet = '$id'";
    if ($koneksi->query($query) === TRUE) {
        $_SESSION['success'] = "Data berhasil dihapus!";
    } else {
        $_SESSION['error'] = "Gagal menghapus data: " . $koneksi->error;
    }

    header("Location: outlet.php");
    exit;
} else {
    $_SESSION['error'] = "Parameter tidak ditemukan!";
    header("Location: outlet.php");
    exit;
}
?>
