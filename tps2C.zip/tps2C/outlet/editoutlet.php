<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "db_laundry");
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id_outlet'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $phone = $_POST['phone'];

    $query = "UPDATE outlet SET nama='$nama', alamat='$alamat', phone='$phone' WHERE id_outlet='$id'";
    if ($koneksi->query($query) === TRUE) {
        $_SESSION['success'] = "Data berhasil diupdate!";
        header("Location: outlet.php");
        exit;
    } else {
        $_SESSION['error'] = "Gagal mengupdate data: " . $koneksi->error;
        header("Location: editoutlet.php?id=$id");
        exit;
    }
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM outlet WHERE id_outlet='$id'";
    $result = $koneksi->query($query);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
    } else {
        echo "Data tidak ditemukan!";
        exit;
    }
} else {
    echo "ID tidak ditemukan!";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Outlet</title>
    <link rel="stylesheet" type="text/css" href="sidebar.css">
    <style>
        .button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="../admin.php">Registrasi Pelanggan</a>
            <a href="outlet.php">Outlet</a>
            <a href="../services/services.php">Services</a>
            <a href="../user/user.php">User</a>
            <a href="../transaksi/transaksi.php">Transaksi</a>
            <a href="../laporan.php">Laporan</a>
    </div>
    <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>

<div class="content">
    <h2>Edit Data Outlet</h2>
    <form action="" method="post">
        <input type="hidden" name="id_outlet" value="<?= $data['id_outlet']; ?>">

        <label>Nama:</label><br>
        <input type="text" name="nama" value="<?= $data['nama']; ?>" required><br><br>

        <label>Alamat:</label><br>
        <textarea name="alamat" required><?= $data['alamat']; ?></textarea><br><br>

        <label>No. Telepon:</label><br>
        <input type="text" name="phone" value="<?= $data['phone']; ?>" required><br><br>

        <button class="btn" type="submit">Update</button>
        <button class="btn" type="button" onclick="window.location.href='outlet.php'">Kembali</button>

    </form>
</div>

</body>
</html>
