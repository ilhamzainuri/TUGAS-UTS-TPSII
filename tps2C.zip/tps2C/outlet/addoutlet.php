<?php
session_start();
include 'koneksi.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $phone = $_POST['phone'];
    $created_at = date('Y-m-d H:i:s');

    $sql = "INSERT INTO outlet (nama, alamat, phone, created_at) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nama, $alamat, $phone, $created_at);

    if ($stmt->execute()) {
        $_SESSION['success'] = 'Data outlet berhasil ditambahkan!';
        header("Location: outlet.php");
        exit;
    } else {
        $_SESSION['error'] = 'Terjadi kesalahan saat menambahkan data.';
    }
    
    

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Customer</title>
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>
<body>
<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="../admin.php">Registrasi Pelanggan</a>
            <a href="outlet.php">Outlet</a>
            <a href="../services/services.php">Services</a>
            <a href="../user/user.php">User</a>
            <a href="../transaksi/transaksi.php">Transaksi</a>
            <a href="#">Laporan</a>
    </div>
    <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>
<div class="content">
    <h1>Tambah Data Outlet</h1>
    <form method="POST" action="">
        <label for="nama">Nama:</label><br>
        <input type="text" id="nama" name="nama" required><br><br>

        <label for="alamat">Alamat:</label><br>
        <textarea id="alamat" name="alamat" required></textarea><br><br>

        <label for="phone">Nomor Telepon:</label><br>
        <input type="text" id="phone" name="phone" required><br><br>

        <button class="btn" type="submit">Tambah</button>
        <button class="btn" type="button" onclick="window.location.href='outlet.php'">Kembali</button>
    </form>
</div>
</body>
</html>