<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_outlet = $_POST['id_outlet'];
    $nama_paket = $_POST['nama_paket'];
    $jenis = $_POST['jenis'];
    $price = $_POST['price'];

    $sql = "INSERT INTO paket (id_outlet, nama_paket, jenis, price) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issi", $id_outlet, $nama_paket, $jenis, $price);

    if ($stmt->execute()) {
        $_SESSION['success'] = 'Data layanan berhasil ditambahkan!';
        header("Location: services.php");
        exit;
    } else {
        $_SESSION['error'] = 'Terjadi kesalahan saat menambahkan data layanan.';
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Layanan</title>
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="../admin.php">Registrasi Pelanggan</a>
            <a href="../outlet/outlet.php">Outlet</a>
            <a href="services.php">Services</a>
            <a href="../user/user.php">User</a>
            <a href="../transaksi/transaksi.php">Transaksi</a>
            <a href="../laporan.php">Laporan</a>
    </div>
    <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>

<div class="content">
    <h1>Tambah Data Layanan</h1>
    <form method="POST" action="">
        <label for="id_outlet">Pilih Outlet:</label><br>
        <select name="id_outlet" id="id_outlet" required>
            <option value="">-- Pilih Outlet --</option>
            <?php
            $query = "SELECT id_outlet, nama FROM outlet";
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id_outlet']}'>{$row['nama']}</option>";
            }
            ?>
        </select><br><br>

        <label for="nama_paket">Nama Paket:</label><br>
        <input type="text" id="nama_paket" name="nama_paket" required><br><br>

        <label for="jenis">Jenis Paket:</label><br>
        <select id="jenis" name="jenis" required>
            <option value="">-- Pilih Jenis --</option>
            <option value="kiloan">Kiloan</option>
            <option value="selimut">Selimut</option>
            <option value="bed_cover">Bed Cover</option>
            <option value="kaos">Kaos</option>
            <option value="lain">Lain-lain</option>
        </select><br><br>

        <label for="price">Harga (Rp):</label><br>
        <input type="number" id="price" name="price" required><br><br>

        <button class="btn" type="submit">Tambah</button>
        <button class="btn" type="button" onclick="window.location.href='services.php'">Kembali</button>
    </form>
</div>
</body>
</html>
