<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "db_laundry");
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_paket = $_POST['id_paket'];
    $id_outlet = $_POST['id_outlet'];
    $nama_paket = $_POST['nama_paket'];
    $jenis = $_POST['jenis'];
    $price = $_POST['price'];

    $query = "UPDATE paket SET id_outlet='$id_outlet', nama_paket='$nama_paket', jenis='$jenis', price='$price' WHERE id_paket='$id_paket'";
    if ($koneksi->query($query) === TRUE) {
        $_SESSION['success'] = "Data layanan berhasil diupdate!";
        header("Location: services.php");
        exit;
    } else {
        $_SESSION['error'] = "Gagal mengupdate data: " . $koneksi->error;
        header("Location: editserv.php?id=$id_paket");
        exit;
    }
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM paket WHERE id_paket='$id'";
    $result = $koneksi->query($query);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
    } else {
        echo "Data tidak ditemukan!";
        exit;
    }
} else {
    echo "ID tidak ditemukan!";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Layanan</title>
    <link rel="stylesheet" type="text/css" href="../sidebar.css">
</head>
<body>

<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="../admin.php">Registrasi Pelanggan</a>
            <a href="../outlet/outlet.php">Outlet</a>
            <a href="services.php">Services</a>
            <a href="../user/user.php">User</a>
            <a href="../transaksi/transaksi.php">Transaksi</a>
            <a href="../laporan.php">Laporan</a>
    </div>
    <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>

<div class="content">
    <h2>Edit Data Layanan</h2>
    <form action="" method="post">
        <input type="hidden" name="id_paket" value="<?= $data['id_paket']; ?>">

        <label>ID Outlet:</label><br>
        <input type="number" name="id_outlet" value="<?= $data['id_outlet']; ?>" required><br><br>

        <label>Nama Paket:</label><br>
        <input type="text" name="nama_paket" value="<?= $data['nama_paket']; ?>" required><br><br>

        <label>Jenis:</label><br>
        <select name="jenis" required>
            <option value="kiloan" <?= $data['jenis'] == 'kiloan' ? 'selected' : '' ?>>Kiloan</option>
            <option value="selimut" <?= $data['jenis'] == 'selimut' ? 'selected' : '' ?>>Selimut</option>
            <option value="bed_cover" <?= $data['jenis'] == 'bed_cover' ? 'selected' : '' ?>>Bed Cover</option>
            <option value="kaos" <?= $data['jenis'] == 'kaos' ? 'selected' : '' ?>>Kaos</option>
            <option value="lain" <?= $data['jenis'] == 'lain' ? 'selected' : '' ?>>Lain-lain</option>
        </select><br><br>

        <label>Harga:</label><br>
        <input type="number" name="price" value="<?= $data['price']; ?>" required><br><br>

        <button class="btn" type="submit">Update</button>
        <button class="btn" type="button" onclick="window.location.href='services.php'">Kembali</button>
    </form>
</div>

</body>
</html>
