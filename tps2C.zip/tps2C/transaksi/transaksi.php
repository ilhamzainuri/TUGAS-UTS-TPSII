<?php
session_start();
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Data Transaksi</title>
    <link rel="stylesheet" href="sidebar.css">
    <style>
        .content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
        }

        .header {
            background-color: #ecf0f1;
            padding: 10px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }

        .table-wrapper {
            width: 110%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            margin-right: auto;
            margin: 10px auto;
            border-collapse: collapse;
            background-color: white;
            min-width: 1200px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        td .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-edit {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-edit:hover {
            background-color: #45a049;
        }

        .btn-delete {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-delete:hover {
            background-color: #e53935;
        }

        .button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }
    </style>
</head>

<body>

<?php include '../notif.php'; ?>

    <div class="sidebar">
        <div>
            <h2>Admin Panel</h2>
            <a href="../admin.php">Registrasi Pelanggan</a>
            <a href="../outlet/outlet.php">Outlet</a>
            <a href="../services/services.php">Services</a>
            <a href="../user/user.php">User</a>
            <a href="transaksi.php">Transaksi</a>
            <a href="../laporan.php">Laporan</a>
        </div>
        <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
    </div>

    <div class="content">
        <div class="header">Data Transaksi</div>
        <a href="addtrans.php" class="button"
            style="margin-left:5px ;display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px; margin-right: 10px;">Tambah
            Transaksi</a>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID Transaksi</th>
                        <th>Kode Invoice</th>
                        <th>Nama Outlet</th>
                        <th>Nama Customer</th>
                        <th>Nama Paket</th>
                        <th>Qty</th>
                        <th>Tanggal</th>
                        <th>Batas Waktu</th>
                        <th>Tanggal Bayar</th>
                        <th>Biaya Tambahan</th>
                        <th>Diskon</th>
                        <th>Pajak</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Pembayaran</th>
                        <th>User</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
        </div>
        <tbody>
            <?php
            $sql = "SELECT 
                        t.*, 
                        o.nama AS nama_outlet, 
                        c.nama AS nama_customer, 
                        p.nama_paket, 
                        u.username 
                    FROM transaksi t 
                    JOIN outlet o ON t.id_outlet = o.id_outlet 
                    JOIN customer c ON t.id_customer = c.id_customer 
                    JOIN paket p ON t.id_paket = p.id_paket 
                    JOIN tb_user u ON t.id_user = u.id_user";

            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id_transaksi']}</td>
                            <td>{$row['kode_invoice']}</td>
                            <td>{$row['nama_outlet']}</td>
                            <td>{$row['nama_customer']}</td>
                            <td>{$row['nama_paket']}</td>
                            <td>{$row['qty']}</td>
                            <td>{$row['tgl']}</td>
                            <td>{$row['batas_waktu']}</td>
                            <td>{$row['tgl_bayar']}</td>
                            <td>Rp " . number_format($row['biaya_tambahan'], 0, ',', '.') . "</td>
                            <td>{$row['diskon']}%</td>
                            <td>{$row['pajak']}%</td>
                            <td>Rp " . number_format($row['total'], 0, ',', '.') . "</td>
                            <td>{$row['status']}</td>
                            <td>{$row['pembayaran']}</td>
                            <td>{$row['username']}</td>
                            <td>
    <div class='action-buttons'>
        <a href='edittransaksi.php?id={$row['id_transaksi']}' class='btn-edit'>Edit</a>
        <a href='deletetransaksi.php?dell={$row['id_transaksi']}' class='btn-delete' onclick='return confirm(\"Yakin ingin menghapus?\");'>Hapus</a>
    </div>
</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='16'>Tidak ada data transaksi.</td></tr>";
            }
            ?>
        </tbody>
        </table>
    </div>
</body>

</html>