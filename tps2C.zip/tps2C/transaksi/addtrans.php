<?php
session_start();
include '../koneksi.php';
include '../notif.php';

function generateKodeInvoice() {
    return 'INV-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
}
$kode_invoice = generateKodeInvoice();

$outlet = $conn->query("SELECT * FROM outlet");
$customer = $conn->query("SELECT * FROM customer");
$paket = $conn->query("SELECT * FROM paket");
$user = $conn->query("SELECT * FROM tb_user");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_outlet = $_POST['id_outlet'];
    $id_customer = $_POST['id_customer'];
    $id_paket = $_POST['id_paket'];
    $qty = $_POST['qty'];
    $tgl = $_POST['tgl'];
    $batas_waktu = $_POST['batas_waktu'];
    $tgl_bayar = $_POST['tgl_bayar'];
    $biaya_tambahan = $_POST['biaya_tambahan'];
    $diskon = $_POST['diskon'];
    $pajak = $_POST['pajak'];
    $total = $_POST['total'];
    $status = $_POST['status'];
    $pembayaran = $_POST['pembayaran'];
    $id_user = $_POST['id_user'];
    $kode_invoice = $_POST['kode_invoice'];

    $stmt = $conn->prepare("INSERT INTO transaksi 
    (id_outlet, kode_invoice, id_customer, id_paket, qty, tgl, batas_waktu, tgl_bayar, biaya_tambahan, diskon, pajak, total, status, pembayaran, id_user)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param(
    "issiisssdddssss",
    $id_outlet,
    $kode_invoice,
    $id_customer,
    $id_paket,
    $qty,
    $tgl,
    $batas_waktu,
    $tgl_bayar,
    $biaya_tambahan,
    $diskon,
    $pajak,
    $total,
    $status,
    $pembayaran,
    $id_user
);

if ($stmt->execute()) {
    $_SESSION['success'] = "Transaksi berhasil ditambahkan!";
    header("Location: transaksi.php");
    exit;
} else {
    $_SESSION['error'] = "Gagal menambahkan transaksi: " . $stmt->error;
}
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Transaksi</title>
    <link rel="stylesheet" href="../sidebar.css">
    <style>
        .content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
        }

        form {
            padding: 20px;
            border-radius: 10px;
            width: 80%;
        }

        label {
            font-weight: bold;
        }

        input, select, textarea {
            width: 100%;
            padding: 8px;
            margin: 6px 0 15px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .btn {
            padding: 10px 20px;
            background: #4CAF50;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .btn:hover {
            background: #45a049;
        }
    </style>
</head>
<body>

<script>
function hitungTotal() {
    let paketSelect = document.getElementById('id_paket');
    let harga = parseFloat(paketSelect.options[paketSelect.selectedIndex].getAttribute('data-harga')) || 0;
    let qty = parseFloat(document.getElementById('qty').value) || 0;
    let biayaTambahan = parseFloat(document.getElementById('biaya_tambahan').value) || 0;
    let diskon = parseFloat(document.getElementById('diskon').value) || 0;
    let pajak = parseFloat(document.getElementById('pajak').value) || 0;

    let subtotal = harga * qty;
    let totalPajak = (subtotal * pajak) / 100;
    let totalDiskon = (subtotal * diskon) / 100;
    let total = subtotal + totalPajak - totalDiskon + biayaTambahan;

    document.getElementById('total').value = Math.round(total);
}
</script>
<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="../admin.php">Registrasi Pelanggan</a>
            <a href="../outlet/outlet.php">Outlet</a>
            <a href="../services.services.php">Services</a>
            <a href="../user/user.php">User</a>
            <a href="transaksi.php">Transaksi</a>
            <a href="../laporan.php">Laporan</a>
    </div>
    <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>

<div class="content">
    <h2>Tambah Data Transaksi</h2>
    <form method="POST">
        <label>Kode Invoice</label>
        <input type="text" name="kode_invoice" value="<?= $kode_invoice ?>" readonly>

        <label>Outlet</label>
        <select name="id_outlet" required>
            <option value="">-- Pilih Outlet --</option>
            <?php while ($o = $outlet->fetch_assoc()) : ?>
                <option value="<?= $o['id_outlet']; ?>"><?= $o['nama']; ?></option>
            <?php endwhile; ?>
        </select>

        <label>Customer</label>
        <select name="id_customer" required>
            <option value="">-- Pilih Customer --</option>
            <?php while ($c = $customer->fetch_assoc()) : ?>
                <option value="<?= $c['id_customer']; ?>"><?= $c['nama']; ?></option>
            <?php endwhile; ?>
        </select>

        <label>Paket</label>
<select name="id_paket" id="id_paket" required onchange="hitungTotal()">
    <option value="">-- Pilih Paket --</option>
    <?php 
    $paket->data_seek(0);
    while ($p = $paket->fetch_assoc()) : ?>
        <option value="<?= $p['id_paket']; ?>" data-harga="<?= $p['price']; ?>">
            <?= $p['nama_paket']; ?> - Rp <?= number_format($p['price'], 0, ',', '.'); ?>
        </option>
    <?php endwhile; ?>
</select>

        <label>Qty</label>
        <input type="number" name="qty" id="qty" required oninput="hitungTotal()">

        <label>Tanggal</label>
        <input type="date" name="tgl" required>

        <label>Batas Waktu</label>
        <input type="date" name="batas_waktu" required>

        <label>Tanggal Bayar</label>
        <input type="date" name="tgl_bayar" required>

        <label>Biaya Tambahan</label>
        <input type="number" name="biaya_tambahan" id="biaya_tambahan" required oninput="hitungTotal()">

        <label>Diskon (%)</label>
        <input type="number" name="diskon" id="diskon" required oninput="hitungTotal()">

        <label>Pajak (%)</label>
        <input type="number" name="pajak" id="pajak" required oninput="hitungTotal()">

        <label>Total</label>
        <input type="number" name="total" id="total" readonly>

        <label>Status</label>
        <select name="status" required>
            <option value="baru">Baru</option>
            <option value="proses">Proses</option>
            <option value="selesai">Selesai</option>
            <option value="diambil">Diambil</option>
        </select>

        <label>Pembayaran</label>
        <select name="pembayaran" required>
            <option value="dibayar">Dibayar</option>
            <option value="belum_dibayar">Belum Dibayar</option>
        </select>

        <label>User</label>
        <select name="id_user" required>
            <option value="">-- Pilih User --</option>
            <?php while ($u = $user->fetch_assoc()) : ?>
                <option value="<?= $u['id_user']; ?>"><?= $u['username']; ?></option>
            <?php endwhile; ?>
        </select>

        <button type="submit" class="btn">Tambah</button>
        <button class="btn" type="button" onclick="window.location.href='transaksi.php'">Kembali</button>
    </form>
</div>
</body>
</html>
