<?php
session_start();
include '../koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM transaksi WHERE id_transaksi = '$id'";
$result = $conn->query($query);
$data = $result->fetch_assoc();

$customers = $conn->query("SELECT * FROM customer");
$outlets = $conn->query("SELECT * FROM outlet");
$pakets = $conn->query("SELECT * FROM paket");
$users = $conn->query("SELECT * FROM tb_user");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_outlet = $_POST['id_outlet'];
    $id_customer = $_POST['id_customer'];
    $id_paket = $_POST['id_paket'];
    $qty = $_POST['qty'];
    $tgl = $_POST['tgl'];
    $batas_waktu = $_POST['batas_waktu'];
    $tgl_bayar = $_POST['tgl_bayar'];
    $biaya_tambahan = $_POST['biaya_tambahan'];
    $diskon = $_POST['diskon'];
    $pajak = $_POST['pajak'];
    $status = $_POST['status'];
    $pembayaran = $_POST['pembayaran'];
    $id_user = $_POST['id_user'];

    $getHarga = $conn->query("SELECT price FROM paket WHERE id_paket = '$id_paket'");
    $hargaRow = $getHarga->fetch_assoc();
    $harga = $hargaRow['harga'];

    $subtotal = $qty * $harga;
    $total_diskon = $subtotal * ($diskon / 100);
    $total_pajak = ($subtotal - $total_diskon) * ($pajak / 100);
    $total = $subtotal - $total_diskon + $total_pajak + $biaya_tambahan;

    $sql = "UPDATE transaksi SET 
                id_outlet='$id_outlet', 
                id_customer='$id_customer', 
                id_paket='$id_paket', 
                qty='$qty', 
                tgl='$tgl', 
                batas_waktu='$batas_waktu', 
                tgl_bayar='$tgl_bayar', 
                biaya_tambahan='$biaya_tambahan', 
                diskon='$diskon', 
                pajak='$pajak', 
                total='$total', 
                status='$status', 
                pembayaran='$pembayaran', 
                id_user='$id_user' 
            WHERE id_transaksi='$id'";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = "Transaksi berhasil diupdate!";
        header("Location: transaksi.php");
        exit;
    } else {
        $_SESSION['error'] = "Gagal update: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Transaksi</title>
    <link rel="stylesheet" href="../sidebar.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f2f2f2; }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: auto;
        }
        .card h2 {
            margin-bottom: 20px;
            color: #333;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px 25px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
        }
        .alert-success, .alert-error {
            margin: 20px auto;
            width: 800px;
            padding: 10px;
            border-radius: 5px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>

<?php include '../notif.php'; ?>

<div class="sidebar">
        <div>
            <h2>Kasir Panel</h2>
            <a href="../kasir.php">Registrasi Pelanggan</a>
            <a href="transaksi.php">Transaksi</a>
            <a href="laporan.php">Laporan</a>
        </div>
        <form action="logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
    </div>
<div class="content">
    <div class="card">
        <h2>Edit Data Transaksi</h2>

        <?php if (isset($_SESSION['success'])) { echo "<div class='alert-success'>{$_SESSION['success']}</div>"; unset($_SESSION['success']); } ?>
        <?php if (isset($_SESSION['error'])) { echo "<div class='alert-error'>{$_SESSION['error']}</div>"; unset($_SESSION['error']); } ?>

        <form method="POST">
            <label>Outlet</label>
            <select name="id_outlet">
                <?php while ($o = $outlets->fetch_assoc()) {
                    echo "<option value='{$o['id_outlet']}' " . ($o['id_outlet'] == $data['id_outlet'] ? 'selected' : '') . ">{$o['nama']}</option>";
                } ?>
            </select>

            <label>Customer</label>
            <select name="id_customer">
                <?php while ($c = $customers->fetch_assoc()) {
                    echo "<option value='{$c['id_customer']}' " . ($c['id_customer'] == $data['id_customer'] ? 'selected' : '') . ">{$c['nama']}</option>";
                } ?>
            </select>

            <label>Paket</label>
            <select name="id_paket">
                <?php while ($p = $pakets->fetch_assoc()) {
                    echo "<option value='{$p['id_paket']}' " . ($p['id_paket'] == $data['id_paket'] ? 'selected' : '') . ">{$p['nama_paket']} - Rp {$p['harga']}</option>";
                } ?>
            </select>

            <label>Qty</label>
            <input type="number" name="qty" value="<?= $data['qty'] ?>">

            <label>Tanggal</label>
            <input type="date" name="tgl" value="<?= $data['tgl'] ?>">

            <label>Batas Waktu</label>
            <input type="date" name="batas_waktu" value="<?= $data['batas_waktu'] ?>">

            <label>Tanggal Bayar</label>
            <input type="date" name="tgl_bayar" value="<?= $data['tgl_bayar'] ?>">

            <label>Biaya Tambahan</label>
            <input type="number" name="biaya_tambahan" value="<?= $data['biaya_tambahan'] ?>">

            <label>Diskon (%)</label>
            <input type="number" name="diskon" value="<?= $data['diskon'] ?>">

            <label>Pajak (%)</label>
            <input type="number" name="pajak" value="<?= $data['pajak'] ?>">

            <label>Status</label>
            <select name="status">
                <?php
                $statuses = ['baru', 'proses', 'selesai', 'diambil'];
                foreach ($statuses as $s) {
                    echo "<option value='$s' " . ($data['status'] == $s ? 'selected' : '') . ">$s</option>";
                }
                ?>
            </select>

            <label>Pembayaran</label>
            <select name="pembayaran">
                <option value="dibayar" <?= $data['pembayaran'] == 'dibayar' ? 'selected' : '' ?>>Dibayar</option>
                <option value="belum_bayar" <?= $data['pembayaran'] == 'belum_bayar' ? 'selected' : '' ?>>Belum Dibayar</option>
            </select>

            <label>User</label>
            <select name="id_user">
                <?php while ($u = $users->fetch_assoc()) {
                    echo "<option value='{$u['id_user']}' " . ($u['id_user'] == $data['id_user'] ? 'selected' : '') . ">{$u['username']}</option>";
                } ?>
            </select>

            <button type="submit">Simpan Perubahan</button>
        </form>
    </div>
</div>
</body>
</html>
