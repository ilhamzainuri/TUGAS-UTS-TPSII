<?php
session_start();
include '../koneksi.php';

if (isset($_GET['dell'])) {
    $id_transaksi = $_GET['dell'];
    
    $sql = "DELETE FROM transaksi WHERE id_transaksi = '$id_transaksi'";
    
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = "Data transaksi berhasil dihapus!";
    } else {
        $_SESSION['error'] = "Gagal menghapus data transaksi: " . $conn->error;
    }

    header("Location: transaksi.php");
    exit;
} else {
    $_SESSION['error'] = "Parameter tidak ditemukan.";
    header("Location: transaksi.php");
    exit;
}
?>
