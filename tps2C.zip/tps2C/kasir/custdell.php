<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "db_laundry");

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

if (isset($_GET['delete'])) {
    $id = $koneksi->real_escape_string($_GET['delete']);

    $query = "DELETE FROM customer WHERE id_customer = '$id'";
    if ($koneksi->query($query) === TRUE) {
        $_SESSION['success'] = "Data berhasil dihapus!";
    } else {
        $_SESSION['error'] = "Gagal menghapus data: " . $koneksi->error;
    }

    header("Location: ../kasir.php");
    exit;
} else {
    $_SESSION['error'] = "Parameter tidak ditemukan!";
    header("Location: ../kasir.php");
    exit;
}
?>
