<?php
session_start();
include 'koneksi.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $jk = $_POST['jk'];
    $phone = $_POST['phone'];
    $created_at = date('Y-m-d H:i:s');

    $sql = "INSERT INTO customer (nama, alamat, JK, phone, created_at) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $nama, $alamat, $jk, $phone, $created_at);

    if ($stmt->execute()) {
        $_SESSION['success'] = 'Data customer berhasil ditambahkan!';
        header("Location: ../kasir.php");
        exit;
    } else {
        $_SESSION['error'] = 'Terjadi kesalahan saat menambahkan data.';
    }
    
    

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Customer</title>
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>
<body>
<div class="sidebar">
    <div>
        <h2>Kasir Panel</h2>
        <a href="../kasir.php">Registrasi Pelanggan</a>
        <a href="transaksi.php">Transaksi</a>
        <a href="laporan">Laporan</a>
    </div>
    <form action="logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>
<div class="content">
    <h1>Tambah Data Customer</h1>
    <form method="POST" action="">
        <label for="nama">Nama:</label><br>
        <input type="text" id="nama" name="nama" required><br><br>

        <label for="alamat">Alamat:</label><br>
        <textarea id="alamat" name="alamat" required></textarea><br><br>

        <label for="jk">Jenis Kelamin:</label><br>
        <select id="jk" name="jk" required>
            <option value="L">Laki-laki</option>
            <option value="P">Perempuan</option>
        </select><br><br>

        <label for="phone">Nomor Telepon:</label><br>
        <input type="text" id="phone" name="phone" required><br><br>

        <button class="btn" type="submit">Tambah</button>
        <button class="btn" type="button" onclick="window.location.href='../kasir.php'">Kembali</button>
    </form>
</div>
</body>
</html>