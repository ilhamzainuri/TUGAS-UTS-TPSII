<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="sidebar.css">
    <style>
        .content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
        }

        .header {
            background-color: #ecf0f1;
            padding: 10px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }
        .btn-edit {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

        .btn-edit:hover {
            background-color: #45a049;
        }

        .btn-delete {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-delete:hover {
            background-color: #e53935;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }
    </style>
</head>

<body>
<?php include 'notif.php'; ?>

<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="admin.php">Registrasi Pelanggan</a>
        <a href="outlet/outlet.php">Outlet</a>
        <a href="services/services.php">Services</a>
        <a href="user/user.php">User</a>
        <a href="transaksi/transaksi.php">Transaksi</a>
        <a href="laporan.php">Laporan</a>
    </div>
    <form action="logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>
    <div class="content">
        <div class="header">Data Customer</div>
        <a href="cust/cust.php" class="button" style="margin-left:60px ;display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px; margin-right: 10px;">Tambah Customer</a>
        <table>
            <thead>
                <tr>
                    <th>ID Customer</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Jenis Kelamin</th>
                    <th>Phone</th>
                    <th>Created At</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>
                <?php
                include 'koneksi.php';

                $sql = "SELECT id_customer, nama, alamat, JK, phone, created_at FROM customer";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id_customer"] . "</td>";
                        echo "<td>" . $row["nama"] . "</td>";
                        echo "<td>" . $row["alamat"] . "</td>";
                        echo "<td>" . $row["JK"] . "</td>";
                        echo "<td>" . $row["phone"] . "</td>";
                        echo "<td>" . $row["created_at"] . "</td>";
                    echo "<td>
                    <a href='cust/editcust.php?id=" . $row['id_customer'] . "' class='btn-edit'>Edit</a>
                    <a href='cust/custdell.php?delete=" . $row['id_customer'] . "' class='btn-delete' onclick='return confirm(\"Yakin ingin menghapus?\");'>Hapus</a>
                    </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>Tidak ada data</td></tr>";
                }
                ?>
            </tbody>
        </table>
    
    </div>
    </div>
</body>

</html>