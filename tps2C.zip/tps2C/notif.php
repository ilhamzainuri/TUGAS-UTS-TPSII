<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if (isset($_SESSION['success'])): ?>
<script>
Swal.fire({
    toast: true,
    position: 'top-end',
    icon: 'success',
    title: '<?= $_SESSION['success']; ?>',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    background: '#f0fff0',
    color: '#333',
    didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer);
        toast.addEventListener('mouseleave', Swal.resumeTimer);
    }
});
</script>
<?php unset($_SESSION['success']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Oops!',
    text: '<?= $_SESSION['error']; ?>'
});
</script>
<?php unset($_SESSION['error']); endif; ?>
