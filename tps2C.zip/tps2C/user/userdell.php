<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "db_laundry");

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

if (isset($_GET['dell'])) {
    $id = $koneksi->real_escape_string($_GET['dell']);

    $query = "DELETE FROM tb_user WHERE id_user = '$id'";
    if ($koneksi->query($query) === TRUE) {
        $_SESSION['success'] = "User berhasil dihapus!";
    } else {
        $_SESSION['error'] = "Gagal menghapus user: " . $koneksi->error;
    }

    header("Location: user.php");
    exit;
} else {
    $_SESSION['error'] = "Parameter tidak ditemukan!";
    header("Location: user.php");
    exit;
}
?>
