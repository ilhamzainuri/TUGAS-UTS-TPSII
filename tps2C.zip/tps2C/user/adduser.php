<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "db_laundry");

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

$outletQuery = "SELECT id_outlet, nama FROM outlet";
$outletResult = $koneksi->query($outletQuery);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username  = $_POST['username'];
    $email     = $_POST['email'];
    $password  = $_POST['password'];
    $id_outlet = $_POST['id_outlet'];
    $role      = $_POST['role'];

    $query = "INSERT INTO tb_user (username, email, password, id_outlet, role) 
              VALUES (?, ?, ?, ?, ?)";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("sssss", $username, $email, $password, $id_outlet, $role);

    if ($stmt->execute()) {
        $_SESSION['success'] = "User berhasil ditambahkan!";
        header("Location: user.php");
        exit;
    } else {
        $_SESSION['error'] = "Gagal menambahkan user: " . $stmt->error;
    }

    $stmt->close();
    $koneksi->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah User</title>
    <link rel="stylesheet" href="../sidebar.css">
</head>
<body>

<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="../admin.php">Registrasi Pelanggan</a>
        <a href="../outlet/outlet.php">Outlet</a>
        <a href="../services/services.php">Services</a>
        <a href="user.php">User</a>
        <a href="../transaksi/transaksi.php">Transaksi</a>
        <a href="../laporan.php">Laporan</a>
    </div>
    <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>

<div class="content">
    <h2>Tambah Data User</h2>
    <form method="POST" action="">
        <label>Username:</label><br>
        <input type="text" name="username" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Password:</label><br>
        <input type="text" name="password" required><br><br>

        <label>Outlet:</label><br>
        <select name="id_outlet" required>
            <option value="">-- Pilih Outlet --</option>
            <?php while ($row = $outletResult->fetch_assoc()) : ?>
                <option value="<?= $row['id_outlet']; ?>"><?= $row['nama']; ?></option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Role:</label><br>
        <select name="role" required>
            <option value="">-- Pilih Role --</option>
            <option value="admin">Admin</option>
            <option value="kasir">Kasir</option>
            <option value="owner">Owner</option>
        </select><br><br>

        <button class="btn" type="submit">Tambah</button>
        <button class="btn" type="button" onclick="window.location.href='user.php'">Kembali</button>
    </form>
</div>

</body>
</html>
