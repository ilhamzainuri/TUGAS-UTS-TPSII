<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "db_laundry");

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_user = $_POST['id_user'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password']; 
    $id_outlet = $_POST['id_outlet'];
    $role = $_POST['role'];

    $query = "UPDATE tb_user SET username='$username', email='$email', password='$password', id_outlet='$id_outlet', role='$role' WHERE id_user='$id_user'";

    if ($koneksi->query($query) === TRUE) {
        $_SESSION['success'] = "Data user berhasil diupdate!";
        header("Location: user.php");
        exit;
    } else {
        $_SESSION['error'] = "Gagal mengupdate data: " . $koneksi->error;
        header("Location: edituser.php?id=$id_user");
        exit;
    }
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $koneksi->query("SELECT * FROM tb_user WHERE id_user='$id'");
    $user = $result->fetch_assoc();


    $outlet_result = $koneksi->query("SELECT * FROM outlet");
} else {
    $_SESSION['error'] = "ID tidak ditemukan!";
    header("Location: user.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data User</title>
    <link rel="stylesheet" href="sidebar.css">
</head>
<body>
<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <a href="../admin.php">Registrasi Pelanggan</a>
        <a href="../outlet/outlet.php">Outlet</a>
        <a href="../services/services.php">Services</a>
        <a href="user.php">User</a>
        <a href="../transaksi/transaksi.php">Transaksi</a>
        <a href="../laporan.php">Laporan</a>
    </div>
    <form action="../logout.php" method="post" style="margin-top:auto;">
        <button class="btn">Logout</button>
    </form>
</div>

<div class="content">
    <h2>Edit Data User</h2>
    <form method="POST" action="">
        <input type="hidden" name="id_user" value="<?= $user['id_user']; ?>">

        <label>Username:</label><br>
        <input type="text" name="username" value="<?= $user['username']; ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?= $user['email']; ?>" required><br><br>

        <label>Password:</label><br>
        <input type="text" name="password" value="<?= $user['password']; ?>" required><br><br>

        <label>Outlet:</label><br>
        <select name="id_outlet" required>
            <option value="">-- Pilih Outlet --</option>
            <?php while ($row = $outlet_result->fetch_assoc()): ?>
                <option value="<?= $row['id_outlet']; ?>" <?= ($row['id_outlet'] == $user['id_outlet']) ? 'selected' : ''; ?>>
                    <?= $row['nama']; ?>
                </option>
            <?php endwhile; ?>
        </select><br><br>

        <label>Role:</label><br>
        <select name="role" required>
            <option value="admin" <?= ($user['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
            <option value="kasir" <?= ($user['role'] == 'kasir') ? 'selected' : ''; ?>>Kasir</option>
            <option value="owner" <?= ($user['role'] == 'owner') ? 'selected' : ''; ?>>Owner</option>
        </select><br><br>

        <button class="btn" type="submit">Update</button>
        <button class="btn" type="button" onclick="window.location.href='user.php'">Kembali</button>
    </form>
</div>

</body>
</html>
